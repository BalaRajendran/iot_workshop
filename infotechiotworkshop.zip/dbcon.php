<?php
 $con=mysql_connect('208.91.198.197:3306','BalajiNandha','@Itengineer007') or die(mysql_error());  
    mysql_select_db('farmingarms') or die("cannot select DB");  
?>